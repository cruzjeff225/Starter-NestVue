<script setup lang="ts">
import { useAuthStore } from '../stores/authStore'
import { useRoute } from 'vue-router'

const auth = useAuthStore()
const route = useRoute()

const navItems = [
  {
    to: '/',
    label: 'Dashboard',
    icon: `<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>`,
    roles: ['superadmin', 'admin_full', 'admin_editor', 'admin_readonly', 'user'],
  },
  {
    to: '/admin/clientes',
    label: 'Clientes',
    icon: `<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>`,
    permission: 'clientes:leer',
  },
  {
    to: '/admin/users',
    label: 'Usuarios',
    icon: `<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>`,
    roles: ['superadmin'],
  },
  {
    to: '/admin/roles-permisos',
    label: 'Roles y Permisos',
    icon: `<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>`,
    roles: ['superadmin'],
  },
  {
    to: '/admin/habitaciones',
    label: 'Habitaciones',
    icon: `<path d="M2 4h20v14a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2z"/><path d="M2 10h20"/><path d="M6 4v14"/><path d="M18 4v14"/>`,
    permission: 'habitaciones:leer',
  },
  {
    to: '/admin/reservaciones',
    label: 'Reservaciones',
    icon: `<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/>`,
    permission: 'reservaciones:leer',
  },
  {
    to: '/admin/facturacion',
    label: 'Facturación',
    icon: `<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/><line x1="9" y1="14" x2="15" y2="14"/><line x1="9" y1="18" x2="15" y2="18"/>`,
    permission: 'facturacion:leer',
  },
]

const visibleItems = navItems.filter(item =>
  item.permission
    ? auth.tienePermiso(item.permission)
    : item.roles?.includes(auth.usuario?.rol ?? '') ?? false
)
</script>

<template>
  <aside class="sidebar">
    <nav class="sidebar-nav">
      <RouterLink v-for="item in visibleItems" :key="item.to" :to="item.to" class="nav-item"
        :class="{ active: route.path === item.to }">
        <svg class="nav-item-icon" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor"
          stroke-width="2" stroke-linecap="round" stroke-linejoin="round" v-html="item.icon" />
        <span>{{ item.label }}</span>
        <div v-if="route.path === item.to" class="active-indicator"></div>
      </RouterLink>
    </nav>

    <div class="sidebar-footer">
      <div class="sidebar-version">v1.0.0</div>
    </div>
  </aside>
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600&display=swap');

.sidebar {
  width: 220px;
  min-height: calc(100vh - 60px);
  background: var(--bg-sidebar);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 16px 12px;
  font-family: 'Sora', sans-serif;
  flex-shrink: 0;
}

:global(.dark) .sidebar {
  background: #1e1b4b;
  border-right-color: #312e81;
}

.sidebar-nav {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 12px;
  border-radius: 10px;
  font-size: 0.85rem;
  font-weight: 400;
  color: var(--text-secondary);
  text-decoration: none;
  transition: all 0.18s;
  position: relative;
  overflow: hidden;
}

:global(.dark) .nav-item {
  color: #94a3b8;
}

.nav-item:hover {
  background: var(--bg-hover);
  color: var(--accent);
}

:global(.dark) .nav-item:hover {
  background: #312e81;
  color: #a5b4fc;
}

.nav-item.active {
  background: var(--bg-active);
  color: var(--text-active);
  font-weight: 500;
}

:global(.dark) .nav-item.active {
  background: #312e81;
  color: #a5b4fc;
}

.nav-item-icon {
  flex-shrink: 0;
  transition: transform 0.18s;
}

.nav-item:hover .nav-item-icon {
  transform: scale(1.1);
}

.active-indicator {
  position: absolute;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 3px;
  height: 60%;
  background: var(--accent);
  border-radius: 99px 0 0 99px;
}

.sidebar-footer {
  padding: 8px 12px;
}

.sidebar-version {
  font-size: 0.72rem;
  color: #cbd5e1;
  font-weight: 300;
}
</style>